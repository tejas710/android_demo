package com.example.jay3165.garglibrary;

/**
 * Created by jay3165 on 3/31/2017.
 */

public class Loginpref {
    public static final String MY_PREF="my_pref";
    public static final String NAME="name";
    public static final String ID="clientid";
    public static final String EMAIL="email";
    public static final String MOB="mobile";
    public static final String PASSWORD="password";
    public static final String ADDRESS="address";
    public static final String CITY="city";
    public static final String STATE="state";
    public static final String ZIP="zip";
    public static final String OTP="rconfirm";
    public static final String ISUSERLIOGIN="isuserlogin";
    public static final String PID="productid";
    public static final String QTY="quantity";
    public static final String TOTAL="grandtotal";
    public static final String PRICE="price";
    public static final String PNAME="pname";

}
