package com.example.jay3165.garglibrary;

/**
 * Created by jay3165 on 2/28/2017.
 */

public class Constant {
    public static String val;
    public static String pass;
    public static String city;
}
